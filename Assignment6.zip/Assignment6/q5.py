# 5. Movie recommendation using Spark dataframes.
# Hint: config("spark.driver.memory", "4g")

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder\
            .appName("q5")\
            .config("spark.shuffle.partitions", "2")\
            .getOrCreate()

movieFile = '/home/sunbeam/Desktop/DBDA/BigData/data/movies/movies.csv'
ratingFile = '/home/sunbeam/Desktop/DBDA/BigData/data/movies/ratings.csv'

m_df = spark.read\
    .option("header", True)\
    .option("inferSchema", True)\
    .csv(movieFile)

r_df = spark.read\
    .option("header", True)\
    .option("inferSchema", True)\
    .csv(ratingFile)

selfjoin = r_df.alias("r1").join(
    r_df.alias("r2"),
    (col("r1.userId") == col("r2.userId")) & (col("r1.movieId") < col("r2.movieId"))
).select(
    col("r1.userId").alias("uid"),
    col("r1.movieId").alias("m1"),
    col("r2.movieId").alias("m2"),
    col("r1.rating").alias("r1"),
    col("r2.rating").alias("r2")
)

corr_df = selfjoin.groupBy("m1", "m2")\
    .agg(
        count("*").alias("cnt"),
        corr("r1", "r2").alias("cor")
    )\
    .filter(col("cor").isNotNull())
# corr_df.show()

movie_recom = corr_df\
    .where((col("cor") > 0.7) & (col("cnt") > 30) & ((col("m1") == 858) | (col("m2") == 858)))\
    .select(when(col("m1")==858, col("m2")).otherwise(col("m1")).alias("mid"))

result = movie_recom\
          .join(m_df, m_df["movieId"] == movie_recom["mid"], how="inner")\
          .select("movieid", "title")

result.show(truncate=False)
spark.stop()