# 2. What are distinct types of calls made to the ﬁre department?

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder\
        .appName("q8-ii")\
        .config("spark.driver.memory", "4g")\
        .getOrCreate()

fire_data_file= "/home/sunbeam/Desktop/DBDA/BigData/data/fire_data/Fire_Department_Calls_for_Service.csv"
fire = spark.read\
        .option("header",True)\
        .option("inferSchema",True)\
        .csv(fire_data_file)

result= fire.select("Call Type").distinct()
result.show(truncate=False)

spark.stop()