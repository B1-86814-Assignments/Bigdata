# 4. What were the most common call types?

# SELECT calltype, COUNT(*) cnt FROM fire_data
# GROUP BY calltype
# ORDER BY cnt DESC
# LIMIT 10;

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder \
    .appName("q8-iv") \
    .config("spark.driver.memory", "4g") \
    .getOrCreate()

filePath = "/home/sunbeam/Desktop/DBDA/BigData/data/fire_data/Fire_Department_Calls_for_Service.csv"

fire = spark.read\
    .option("header", True)\
    .option("inferSchema", True)\
    .csv(filePath)

result = fire.groupBy("Call Type")\
    .agg(count(expr("*")).alias("cnt"))\
    .orderBy(col("cnt").desc())\
    .limit(5)

# result = fire.groupBy("Call Type")\
#     .agg(count("*").alias("cnt"))\
#     .orderBy(col("cnt").desc())\
#     .limit(5)

result.printSchema()
result.show()


