# 8. Load Fire Service Calls with pre-deﬁned schema. Repeat all 10 Hive assignments on that dataset.
# Do the assignments using Dataframe syntax.
# Use Linux command below to create sample dataset.

# i. How many distinct types of calls were made to the ﬁre department?

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark= SparkSession.builder\
        .appName("q8-i")\
        .config("spark.driver.memory", "4g")\
        .getOrCreate()

fire_data_file= "/home/sunbeam/Desktop/DBDA/BigData/data/fire_data/Fire_Department_Calls_for_Service.csv"

fire= spark.read\
        .option("header",True)\
        .option("inferSchema",True)\
        .csv(fire_data_file)
# fire.show(truncate=False)

result = fire.groupBy(col("Call Type")).count()
result.show(truncate=False)

spark.stop()
