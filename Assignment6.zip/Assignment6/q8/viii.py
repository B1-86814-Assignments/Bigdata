# 8. How many distinct years of data are in the CSV ﬁle?
#
# SELECT DISTINCT YEAR(calldate) FROM fire_data;

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder \
    .appName("q8-viii") \
    .config("spark.driver.memory", "4g") \
    .getOrCreate()

filePath = "/home/sunbeam/Desktop/DBDA/BigData/data/fire_data/Fire_Department_Calls_for_Service.csv"

df = spark.read\
    .option("header", True)\
    .option("inferSchema", True)\
    .csv(filePath)

result = df.withColumns({"year": year(to_date(from_unixtime(unix_timestamp("Call Date",'MM/dd/yyyy'))))})\
    .select("year")\
    .distinct()

result.show()

spark.stop()
