# 9. What week of the year in 2018 had the most ﬁre calls?
#
# SELECT weekofyear(calldate) week_of_year, COUNT(*) cnt_call FROM fire_data
# WHERE YEAR(calldate) = 2018
# GROUP BY weekofyear(calldate)
# ORDER BY cnt_call DESC
# LIMIT 1;

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder \
    .appName("q8-x") \
    .config("spark.driver.memory", "4g") \
    .getOrCreate()

filePath = "/home/sunbeam/Desktop/DBDA/BigData/data/fire_data/Fire_Department_Calls_for_Service.csv"

df = spark.read\
    .option("header", True)\
    .option("inferSchema", True)\
    .csv(filePath)

res = df.withColumn("callDate", to_date(from_unixtime(unix_timestamp("Call Date", 'MM/dd/yyyy'))))\
    .where(year("callDate") == 2018)\
    .groupBy(weekofyear("callDate"))\
    .agg(count("*").alias("call_cnt"))\
    .orderBy(desc("call_cnt"))\
    .limit(1)

res.show()

spark.stop()