# 7. What was the sum of all calls, average, min, and max of the call response times?
#
# SELECT count(*) cnt, AVG((UNIX_TIMESTAMP(responsedtime) - UNIX_TIMESTAMP(reciveddate))/60) avg,
# MIN((UNIX_TIMESTAMP(responsedtime) - UNIX_TIMESTAMP(reciveddate))/60) min, MAX((UNIX_TIMESTAMP(responsedtime) -
# UNIX_TIMESTAMP(reciveddate))/60) max FROM fire_data;

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder \
    .appName("q8-vii") \
    .config("spark.driver.memory", "4g") \
    .getOrCreate()

filePath = "/home/sunbeam/Desktop/DBDA/BigData/data/fire_data/Fire_Department_Calls_for_Service.csv"

df = spark.read\
    .option("header", True)\
    .option("inferSchema", True)\
    .csv(filePath)

df1 = df.withColumns({"resp": unix_timestamp("Response DtTm", 'MM/dd/yyyy HH:mm:ss a')/60,
                      "rec": unix_timestamp("Received DtTm", 'MM/dd/yyyy HH:mm:ss a')/60})

result = df1.agg(count("*").alias("cnt"),
                 avg(col("resp") - col("rec")).alias("avg"),
                 min(col("resp") - col("rec")).alias("min"),
                 max(col("resp") - col("rec")).alias("max"))

result.show()

spark.stop()
