# 3. Find out all responses for delayed times greater than 5 mins?

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder \
    .appName("q8-iii") \
    .config("spark.driver.memory", "4g") \
    .getOrCreate()

fire_data_file = "/home/sunbeam/Desktop/DBDA/BigData/data/fire_data/Fire_Department_Calls_for_Service.csv"

fire = spark.read \
    .option("header", True) \
    .option("inferSchema", True) \
    .csv(fire_data_file)

fire = fire.withColumn("Response_DtTm", to_timestamp("Response DtTm", "MM/dd/yyyy hh:mm:ss a")) \
           .withColumn("Received_DtTm", to_timestamp("Received DtTm", "MM/dd/yyyy hh:mm:ss a"))
fire.printSchema()

result = fire.withColumn("ResponseDelayMins",
                         (minute("Response_DtTm") - minute("Received_DtTm"))) \
             .filter(col("ResponseDelayMins") > 5)

result.select("Call Number", "Response_DtTm", "Received_DtTm", "ResponseDelayMins").show()

spark.stop()
