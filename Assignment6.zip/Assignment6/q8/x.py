# 10. What neighborhoods in San Francisco had the worst response time in 2018?
#
# SELECT neighborhood_bound FROM fire_data
# WHERE city = 'San Francisco' AND YEAR(calldate) = 2018
# ORDER BY (UNIX_TIMESTAMP(responsedtime) - UNIX_TIMESTAMP(reciveddate))/60 DESC
# LIMIT 1;

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder \
    .appName("q8-x") \
    .config("spark.driver.memory", "4g") \
    .getOrCreate()

filePath = "/home/sunbeam/Desktop/DBDA/BigData/data/fire_data/Fire_Department_Calls_for_Service.csv"

df = spark.read\
    .option("header", True)\
    .option("inferSchema", True)\
    .csv(filePath)

df1 = df.withColumns({"resp": unix_timestamp("Response DtTm", 'MM/dd/yyyy HH:mm:ss a')/60,
                      "rec": unix_timestamp("Received DtTm", 'MM/dd/yyyy HH:mm:ss a')/60,
                      "year": year(to_date(from_unixtime(unix_timestamp("Call Date",'MM/dd/yyyy'))))})\
    .where((col("City") == 'San Francisco') & (col("year") == 2018))\
    .sort(desc(col("resp") - col("rec")))\
    .select("Neighborhooods - Analysis Boundaries")\
    .limit(1)

df1.show()

spark.stop()