# 6. What San Francisco neighborhoods are in the zip codes 94102 and 94103?
#
# SELECT COUNT(neighborhood_bound) FROM fire_data
# WHERE city = 'San Francisco' AND (zipcode = 94102 OR zipcode = 94103);

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder \
    .appName("q8-vi") \
    .config("spark.driver.memory", "4g") \
    .getOrCreate()

filePath = "/home/sunbeam/Desktop/DBDA/BigData/data/fire_data/Fire_Department_Calls_for_Service.csv"

df = spark.read\
    .option("header", True)\
    .option("inferSchema", True)\
    .csv(filePath)

res = df.filter((col("City") == "San Francisco") & ((col("Zipcode of Incident") == 94102) | (col("Zipcode of Incident") == 94103)))\
    .count()

# res = df.where((col("City") == "San Francisco") & ((col("Zipcode of Incident") == 94102) | (col("Zipcode of Incident") == 94103)))\
#     .count(col())

print(res)

spark.stop()