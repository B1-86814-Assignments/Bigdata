# 5. What zip codes accounted for the most common calls?
#
# SELECT calltype, zipcode, COUNT(*) cnt
# FROM fire_data
# GROUP BY calltype, zipcode ORDER BY cnt DESC
# LIMIT20;

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder \
    .appName("q8-v") \
    .config("spark.driver.memory", "4g") \
    .getOrCreate()

filePath = "/home/sunbeam/Desktop/DBDA/BigData/data/fire_data/Fire_Department_Calls_for_Service.csv"

df = spark.read\
    .option("header", True)\
    .option("inferSchema", True)\
    .csv(filePath)

result = df.groupBy("Call Type", "Zipcode of Incident")\
    .agg(count(expr("*")).alias("cnt"))\
    .sort("cnt", ascending=False)\
    .limit(20)

result.printSchema()
result.show()

spark.stop()