# 1. Wordcount using Spark Dataframes and ﬁnd top 10 words (except stopwords). Take ﬁle from HDFS/S3.

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

# create spark session
spark = SparkSession.builder \
    .appName("q1") \
    .config("spark.sql.shuffle.partitions", "2") \
    .getOrCreate()

# dataframe creation
licenseFile = "hdfs://localhost:9000/user/ayush/LICENSE"
licdf = spark.read.text(licenseFile)
# licdf.printSchema()
# licdf.show()

result = licdf\
            .select(explode(split(lower("value"), "[^a-z]")).alias("word"))\
            .where("word NOT IN ('', 'in', 'as', 'is', 'are', 'a', 'the', 'for', 'you', 'i', 'by', 'or', 'and', 'under', 'over', 'he', 'she', 'they', 'it')")\
            .groupBy("word").count()

result.show()

spark.stop()