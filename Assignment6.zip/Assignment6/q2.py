# 2. Find max sal, min sal, avg sal, total sal per dept per job in emp.csv ﬁle.

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

# create spark session
spark = SparkSession.builder \
    .appName("q2") \
    .config("spark.sql.shuffle.partitions", "2") \
    .getOrCreate()

# dataframe creation
empFile = "/home/sunbeam/Desktop/DBDA/BigData/data/emp.csv"
empSchema = "empno INT, ename STRING, job STRING, mgr INT, hire DATE, sal DOUBLE, comm DOUBLE, deptno INT"

df = spark.read \
    .schema(empSchema) \
    .option("path", empFile) \
    .format("csv") \
    .load()


# mutliple aggregate operations
result= df.groupBy("deptno","job") \
            .agg(avg("sal").alias("avgsal"), max("sal").alias("maxsal"), min("sal").alias("minsal"),
         sum("sal").alias("totalsal"))
# result.printSchema()
result.show()



# destroy spark session
spark.stop()


