# 3. Find deptwise total sal from emp.csv and dept.csv. Print dname and total sal.

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark= SparkSession.builder\
        .appName("q3")\
        .config("spark.shuffle.partitions","2")\
        .getOrCreate()

#dataframe creation
empFile= "/home/sunbeam/Desktop/DBDA/BigData/data/emp.csv"
empSchema = "empno INT, ename STRING, job STRING, mgr INT, hire DATE, sal DOUBLE, comm DOUBLE, deptno INT"

df1 = spark.read\
        .schema(empSchema)\
        .option("path",empFile)\
        .format("csv")\
        .load()

deptFile = "/home/sunbeam/Desktop/DBDA/BigData/data/dept.csv"
deptSchema= "deptno INT, dname STRING, city STRING"

df2 = spark.read\
        .schema(deptSchema)\
        .option("path",deptFile)\
        .format("csv")\
        .load()

result= df1.join(df2, df1["deptno"] == df2["deptno"], how="inner")\
        .groupBy("dname")\
        .sum("sal")\
        .select("dname","sum(sal)")\
        .withColumnRenamed("sum(sal)","total_sal")
        

result.show()
            
            
spark.stop()