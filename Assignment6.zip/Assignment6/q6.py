# 6. Count number of movie ratings per month using sql query (using temp views).

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder\
            .appName("q6")\
            .config("spark.shuffle.partitions", "2")\
            .getOrCreate()

ratingSchema = "userId INT, movieId INT, rating DOUBLE, timestamp BIGINT"
ratings = spark.read\
                .option("header", True)\
                .schema(ratingSchema)\
                .csv("/home/sunbeam/Desktop/DBDA/BigData/data/movies/ratings.csv")

# result = ratings.withColumn("month", month(from_unixtime(col("timestamp"))))\
#                 .groupBy("month")\
#                 .count()\
#                 .orderBy("month")
# result.show()

ratings.createTempView("ratings_view")

result= spark.sql("SELECT MONTH(FROM_UNIXTIME(timestamp)) month, COUNT(*) FROM ratings_view GROUP BY month ORDER BY month;")
result.show()

spark.stop()
