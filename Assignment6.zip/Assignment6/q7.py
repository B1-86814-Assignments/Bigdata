# 7. Implement movie recommendation system using temp views.
# Hint: config("spark.driver.memory", "4g")

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder\
    .appName("Q7")\
    .config("spark.driver.memory", "4g")\
    .getOrCreate()

movieFile = '/home/sunbeam/Desktop/DBDA/BigData/data/movies/movies.csv'
ratingFile = '/home/sunbeam/Desktop/DBDA/BigData/data/movies/ratings.csv'



m_df = spark.read\
    .option("header", True)\
    .option("inferSchema", True)\
    .csv(movieFile)

r_df = spark.read\
    .option("header", True)\
    .option("inferSchema", True)\
    .csv(ratingFile)

r_df.printSchema()

# CREATE VIEW movie_pairs AS
# SELECT r1.uid,
# r1.mid m1,
# r1.rating r1,
# r2.mid m2,
# r2.rating r2
# FROM ratings_orc r1
# INNER JOIN ratings_orc r2 ON r1.uid = r2.uid
# WHERE r1.mid < r2.mid;

r_df.createOrReplaceTempView("rating")
m_df.createOrReplaceTempView("movie")

moviePairs = spark.sql(r"SELECT r1.userId uid, r1.movieId m1, r1.rating r1, r2.movieId m2, r2.rating r2 "
                       r"FROM rating r1 "
                       r"INNER JOIN rating r2 ON r1.userId = r2.userId "
                       r"WHERE r1.movieId < r2.movieId")

moviePairs.createOrReplaceTempView("movie_p")

# CREATE MATERIALIZED VIEW corr_movies AS
# SELECT m1, m2, COUNT(m1) cnt, CORR(r1,r2) cor
# FROM movie_pairs
# GROUP BY m1, m2
# HAVING CORR(r1,r2) IS NOT NULL;

corr_moives = spark.sql(r"SELECT m1, m2, COUNT(m1) cnt, CORR(r1, r2) corr "
                        r"FROM movie_p "
                        r"GROUP BY m1, m2 "
                        r"HAVING CORR(r1, r2) IS NOT NULL")

corr_moives.createOrReplaceTempView("corr_m")

# WITH movie_recom AS (
# SELECT IF(m1= 858, m2, m1) movieid FROM corr_movies c
# WHERE cor > 0.7 AND cnt > 30 AND (m1 = 858 or m2 = 858)
# )
# SELECT mr.movieid, ms.title FROM movie_recom mr
# INNER JOIN movie_staging_orc ms ON mr.movieid = ms.movieid;

movie_recom = spark.sql(r"SELECT IF(m1=858, m2, m1) movieId FROM corr_m c "
                        r"WHERE corr > 0.7 AND cnt > 30 AND (m1 = 858 or m2 = 858)")

movie_recom.createOrReplaceTempView("movie_r")

result = spark.sql(r"SELECT mr.movieId, ms.title FROM movie_r mr "
                   r"INNER JOIN movie ms ON mr.movieId = ms.movieId")

result.printSchema()
result.show(truncate=False)

spark.stop()
