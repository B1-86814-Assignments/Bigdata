# 4. Count number of movie ratings per year. Hint: convert time column to TIMESTAMP.
from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder\
        .appName("q4")\
        .config("spark.shuffle.partitions","2")\
        .getOrCreate()

#dataframe creation
ratings = spark.read\
            .option("header", True)\
            .option("inferSchema", True)\
            .csv("/home/sunbeam/Desktop/DBDA/BigData/data/movies/ratings.csv")

result1 = ratings.select("userId","movieId","rating",year(from_unixtime("timestamp")).alias("year"))
result = result1.groupBy("year")\
            .count()

result.show()

spark.stop()